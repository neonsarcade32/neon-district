IPAD PROXY READER

This project uses your existing SOCKS5 proxy at 127.0.0.1:55555 and provides a read-only HTTPS page viewer over HTTP port 3000. GitHub Codespaces can privately forward port 3000 as HTTPS to Safari.

Requirements: Node.js in GitHub Codespaces; existing SOCKS5 proxy running at 127.0.0.1:55555.

Instructions:
1. In Codespaces, upload the ZIP to the /workspaces/neon-district directory.
2. Run:
   mkdir -p /tmp/ipad-proxy-reader
   unzip -o /workspaces/neon-district/ipad-proxy-reader.zip -d /tmp/ipad-proxy-reader
   cd /tmp/ipad-proxy-reader
   npm install
   npm start
3. Open the Ports tab, forward port 3000, leave its visibility PRIVATE, and open its HTTPS link from Safari.

This is a simplified page reader with links and images, NOT a VPN or a complete browser. Websites requiring JavaScript, forms, cookies, or login will not work correctly. Do not enter passwords. Never set either port public. /tmp files may disappear if the Codespace is rebuilt.
