const http = require('node:http');
const https = require('node:https');
const { SocksProxyAgent } = require('socks-proxy-agent');
const cheerio = require('cheerio');
const sanitize = require('sanitize-html');

const proxy = new SocksProxyAgent('socks5://127.0.0.1:55555');
const escapeHTML = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function safeURL(input) {
  const url = new URL(input);
  const host = url.hostname.toLowerCase();
  if (url.protocol !== 'https:' || url.port || url.username || url.password ||
      !/^[a-z\d.-]+\.[a-z]{2,}$/i.test(host) ||
      host.includes('..') || /(^|\.)(localhost|local|internal|test|invalid|example)$/.test(host)) {
    throw Error('Enter a public HTTPS website address (such as https://www.wikipedia.org).');
  }
  return url;
}

function fetchViaProxy(input, maxBytes = 2_000_000, hops = 0) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = safeURL(input); } catch (error) { return reject(error); }
    const request = https.get(url, { agent: proxy, timeout: 15000,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; CodespacesReader/1.0)' } }, response => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.resume();
        if (hops >= 4) return reject(Error('Too many redirects'));
        return fetchViaProxy(new URL(response.headers.location, url).href, maxBytes, hops + 1).then(resolve, reject);
      }
      if (response.statusCode !== 200) { response.resume(); return reject(Error('Website returned HTTP ' + response.statusCode)); }
      const chunks = []; let length = 0;
      response.on('data', chunk => {
        length += chunk.length;
        if (length > maxBytes) request.destroy(Error('Page is too large'));
        else chunks.push(chunk);
      });
      response.on('end', () => resolve({ body: Buffer.concat(chunks), type: response.headers['content-type'] || '', url: url.href }));
      response.on('error', reject);
    });
    request.on('timeout', () => request.destroy(Error('Website timed out')));
    request.on('error', reject);
  });
}

function viewer(address, content, error = '') {
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>My Proxy Reader</title><style>
  body{margin:0;background:#f5f7fb;color:#172033;font:16px system-ui} header{background:#172033;color:white;padding:18px}
  form{display:flex;gap:8px;max-width:950px;margin:auto} input{flex:1;min-width:0;border:0;border-radius:10px;padding:14px;font-size:16px}
  button{border:0;border-radius:10px;padding:12px 18px;background:#89e4be;font-weight:700}
  main{max-width:900px;margin:28px auto;background:white;padding:24px;border-radius:16px;overflow-wrap:anywhere}
  img{max-width:100%;height:auto} a{color:#1357a5} p,li{line-height:1.6} .error{color:#a01936}
  </style><header><form action="/" method="get"><input name="url" type="url" required placeholder="https://www.wikipedia.org" value="${escapeHTML(address)}"><button>Go</button></form></header>
  <main>${error ? `<p class="error">${escapeHTML(error)}</p>` : content || '<h2>Proxy Reader</h2><p>Enter a public HTTPS website above. This is a basic reader, not a full web browser.</p>'}</main></html>`;
}

http.createServer(async (req, res) => {
  const route = new URL(req.url, 'http://localhost');
  const address = route.searchParams.get('url') || '';
  res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; img-src 'self'; form-action 'self'; base-uri 'none'");
  try {
    if (route.pathname === '/img' && address) {
      const image = await fetchViaProxy(address, 3_000_000);
      if (!/^image\/(png|jpeg|gif|webp|avif)(;|$)/i.test(image.type)) throw Error('Unsupported image');
      res.setHeader('Content-Type', image.type); res.end(image.body); return;
    }
    if (route.pathname !== '/') { res.writeHead(404); res.end('Not found'); return; }
    if (!address) { res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(viewer('', '')); return; }
    const page = await fetchViaProxy(address);
    if (!/^text\/html(?:;|$)/i.test(page.type)) throw Error('This link is not an HTML page');
    const $ = cheerio.load(page.body.toString('utf8'));
    const title = $('title').first().text() || page.url;
    $('script,style,iframe,form,object,embed,svg,video,audio,head,nav,footer,header').remove();
    $('a').each((_, element) => {
      try { $(element).attr('href', '/?url=' + encodeURIComponent(safeURL(new URL($(element).attr('href'), page.url)).href)); }
      catch { $(element).removeAttr('href'); }
    });
    $('img').each((_, element) => {
      try { $(element).attr('src', '/img?url=' + encodeURIComponent(safeURL(new URL($(element).attr('src'), page.url)).href)); }
      catch { $(element).remove(); }
    });
    const source = $('main').first().html() || $('article').first().html() || $('body').html() || '';
    const safe = sanitize(source, { allowedTags: ['h1','h2','h3','h4','p','br','ul','ol','li','a','img','blockquote','strong','em','b','i','code','pre','div','span','table','thead','tbody','tr','th','td'],
      allowedAttributes: { a:['href'], img:['src','alt','title'] }, allowedSchemes: ['https'] });
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(viewer(address, `<h2>${escapeHTML(title)}</h2><hr>${safe || '<p>This website needs JavaScript, so it cannot be shown here.</p>'}`));
  } catch (error) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(viewer(address, '', error.message));
  }
}).listen(3000, '0.0.0.0', () => console.log('Proxy Reader is ready on port 3000'));
